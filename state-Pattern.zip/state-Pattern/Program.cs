﻿using System;

// Demo of State Pattern (state management example)
//  BankAccount State
//          Silver
//          Gold
//          Platinum

namespace Demo08_StatePattern
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BankAccount account = new BankAccount("Ganpat University");

            account.Deposit(20000.00);
            account.Deposit(7000.00);
            account.Deposit(85000.00);
            account.Withdraw(90000.00);
            account.Withdraw(2000.00);
        }
    }
}
