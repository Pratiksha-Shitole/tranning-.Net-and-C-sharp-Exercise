﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo06_MethodOverloading
{
    class Demo
    {
        public void DoSomething(int i)
        {
            Console.WriteLine("Received Integer: {0}", i);
        }

        public void DoSomething(string s)
        {
            Console.WriteLine("Received String: {0}", s);
        }

        public void DoSomething(bool b) 
        {
            Console.WriteLine("Received Boolean: {0}", b);
        }
    }
}
