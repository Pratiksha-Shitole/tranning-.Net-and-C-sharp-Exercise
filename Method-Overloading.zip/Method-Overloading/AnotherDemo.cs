﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo06_MethodOverloading
{
    class AnotherDemo
    {
        public void DoSomething(object o)
        {
           if(o is int)
            {
                Console.WriteLine("Received an Integer!");
            }
           else if( o is bool )                     // IS OPERATOR - Type checking operator
            {
                Console.WriteLine("Received a Boolean");
                bool b = (bool)o;               // unboxing
                Console.WriteLine("Received value: {0}", b);
            }
        }

    }
}
