﻿using System;

// Inheritance
// Method Override

namespace Demo07_MethodOverriding
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Demo obj = new Demo();
            obj.m();


            AnotherDemo obj2 = new AnotherDemo();
            obj2.m();
            obj2.n();

        }
    }
}
