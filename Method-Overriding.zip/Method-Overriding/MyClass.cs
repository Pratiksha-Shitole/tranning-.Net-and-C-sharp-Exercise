﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo07_MethodOverriding
{
    
    // Base Class / Parent Class
    class Demo
    {
        public void m()
        {

        }

        // method body will exist
        // mark the method as "virtual" to grant permission to the child class to redefine the signature.
        virtual public void DoSomething()
        {

        }
    }



    // Derived Class / Child Class
    class AnotherDemo : Demo
    {
        public void n()
        {

        }

        // the child redefines the signature by marking it as "override"
        override public void DoSomething()
        {

        }
    }

}
